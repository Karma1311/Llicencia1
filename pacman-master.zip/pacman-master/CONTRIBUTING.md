The coding of this project follows [Google style](https://github.com/google/styleguide).
